Documentation and examples for using Post Affiliate Pro API can be found in our knowledgebase:

http://support.qualityunit.com/knowledgebase/post-affiliate-pro/programmers-documentation/api.html
