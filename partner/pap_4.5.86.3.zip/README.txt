This is Post Affiliate Pro (http://www.qualityunit.com/postaffiliatepro) - Affiliate software 
from Quality Unit (http://www.qualityunit.com)

It is commercial software, and only licensed customers are permitted
to use this software. This software is copyright (c) Quality Unit.
If you have received this software without a license, you must
not use the software, and you must destroy your copy of it immediately.

For details about installation read:
http://support.qualityunit.com/knowledgebase/post-affiliate-pro/installation-and-upgrade/clean-installation.html

For details about update to the latest version read:
http://support.qualityunit.com/knowledgebase/post-affiliate-pro/installation-and-upgrade/upgrade-to-the-latest-version.html

For details about upgrade from PAP3 read:
http://support.qualityunit.com/knowledgebase/post-affiliate-pro/installation-and-upgrade/upgrade-from-version-3.html
 
For details about changes read:
http://bugs.qualityunit.com/mantis/changelog_page.php