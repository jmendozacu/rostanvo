This is accounts directory. It needs to be writable by web server.

It contains application settings, templates, cache, .. 