		<div class="fix"></div>

	</div><!--/columns -->
	
	<div id="footer">
		<p>Copyright &copy; <a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a>. <a href="http://www.bloggeraz.com">Powered</a> <a href="http://www.malaysiastory.com">b</a><a href="http://www.animalaqua.com">y</a> <a href="http://www.wordpress.org">Wordpress</a>.</p>
</div><!--/footer -->

</div><!--/page -->

<?php wp_footer(); ?>

</body>
</html>