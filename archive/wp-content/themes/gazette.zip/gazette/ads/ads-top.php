<div class="ads">

	<a <?php do_action('premiumnews_external_ad_link'); ?> href="<?php echo "$dest_url[1]"; ?>"><img src="<?php echo "$img_url[1]"; ?>" alt="" /></a>

	<a <?php do_action('premiumnews_external_ad_link'); ?> href="<?php echo "$dest_url[2]"; ?>"><img src="<?php echo "$img_url[2]"; ?>" alt="" /></a>

	<a <?php do_action('premiumnews_internal_ad_link'); ?> href="<?php echo "$ad_page"; ?>"><img src="<?php bloginfo('template_directory'); ?>/images/ad-here.gif" alt="Advertise Here" class="last" /></a>

</div><!--/ads-->