<?php get_header(); ?>

		<div class="col1">
				
			<div id="archivebox">
				
					<h3><em>404 |</em> Page Not Found!</h3>
					<div class="archivefeed">Sorry, but the page you were looking for is not here.</div>				
			
			</div><!--/archivebox-->	        					

		</div><!--/col1-->

<?php get_sidebar(); ?>

<?php get_footer(); ?>	
